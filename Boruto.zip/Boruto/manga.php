<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>Uzumaki Boruto</title>
  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css"
    href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,700|Raleway:400,700&display=swap"
    rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }

    body {
      background-color: #fcf8f6e8;
    }
  </style>

  
  <!-- Custom styles for this template -->
  <link href="product.css" rel="stylesheet">

</head>

<body>
    
    <header class="site-header sticky-top py-1">
      <nav class="container d-flex flex-column flex-md-row justify-content-between">
        <a class="py-2" href="#" aria-label="Product">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="d-block mx-auto" role="img" viewBox="0 0 24 24"><title>Product</title><circle cx="12" cy="12" r="10"/><path d="M14.31 8l5.74 9.94M9.69 8h11.48M7.38 12l5.74-9.94M9.69 16L3.95 6.06M14.31 16H2.83m13.79-4l-5.74 9.94"/></svg>
        </a>
        <a class="py-2 d-none d-md-inline-block" href="index.html">Home</a>
        <a class="py-2 d-none d-md-inline-block" href="manga.php">Manga</a>
        <a class="py-2 d-none d-md-inline-block" href="jersey & khunai.php">Jersey & Khunai</a>
        <a class="py-2 d-none d-md-inline-block" href="food.php">Food</a>
        <a class="py-2 d-none d-md-inline-block" href="about us.php">About us</a>
      </nav>
    </header>

    <main>
      <img src="image/boruto-manga.jpg" class="d-block w-100" alt="Cinque Terre">
  <div class="px-4 pt-5 my-5 text-center border-bottom">
    <h1 class="display-4 fw-bold">Boruto Manga Online</h1>
    <div class="col-lg-6 mx-auto">
      <p class="lead mb-4">If you like boruto manga, you can support me.<br>Thanks</p>
      <div class="d-grid gap-2 d-sm-flex justify-content-sm-center mb-5">
        <a class="py-2 d-none d-md-inline-block" href="manga.php">Boruto: Naruto Next Generations</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a class="py-2 d-none d-md-inline-block" href="chapter2.php">Boruto: Two Blue Vortex</a>
      </div>
    </div>
    <div class="overflow-hidden" style="max-height: 80vh;">
      <div class="container px-5">
        <img src="image/ch1.jpg">
      </div>
    </div>
    <h1 class="fw-light">Chapter 1</h1>
  </div>

  <div class="container">
       <div class="row">
    <?php
error_reporting(1);
include('connection.php');
$data="SELECT * FROM manga ORDER BY id DESC";
$val=$con->query($data);
if ($val->num_rows > 0) {
while(list($id,$name,$title,$price) = mysqli_fetch_array($val)){
    echo "<div class='col-4'>
    <div class='card'>
    
    <div class='card-content'>
        <p ><b>$name:$title<b></p>   
        <p style='color:green'>Price - $price $</p>
        
        <center>  <a href='order.php?name=$name&price=$price'>Buy</a></center>
    </div>
</div>
<br><br>
    </div>";
  
}}else{
    echo "<h1 colspan='8' class='text-center'>
   <b> No data available</b></h1>";
}
?>
</div>
</div>

    </main>

    <section class="container-fluid footer_section">
      <p>
        &copy; 2024 All Rights Reserved. Design by
        <a href="https://www.facebook.com/profile.php?id=100008265902254&mibextid=LQQJ4d">Hein Thant</a>
      </p>
    </section>

  </body>
  </html>