-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 29, 2024 at 02:33 PM
-- Server version: 8.2.0
-- PHP Version: 8.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `borutodb`
--

-- --------------------------------------------------------

--
-- Table structure for table `boruto_order`
--

DROP TABLE IF EXISTS `boruto_order`;
CREATE TABLE IF NOT EXISTS `boruto_order` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(80) NOT NULL,
  `Phone` int NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Product` varchar(80) NOT NULL,
  `Price` int NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `boruto_order`
--

INSERT INTO `boruto_order` (`ID`, `Name`, `Phone`, `Address`, `Product`, `Price`) VALUES
(2, 'Hein Thant', 2147483647, 'Pazundaung', 'Boruto Two Blue Vortex', 2),
(4, 'Hein Thant', 2147483647, 'Botahtaung', 'Boruto Two Blue Vortex', 2),
(5, 'Recess', 2147483647, 'Bahan', 'Boruto Chapter 1', 2),
(6, 'Recess', 2147483647, 'Bangkok', 'Boruto Cosplay ', 8000),
(7, 'Recess', 2147483647, 'Time City', 'Lemon Burger', 400);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
CREATE TABLE IF NOT EXISTS `feedback` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(80) NOT NULL,
  `Email` varchar(80) NOT NULL,
  `Suggestion` varchar(80) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`ID`, `Name`, `Email`, `Suggestion`) VALUES
(1, 'Hein Thant', 'heinthantaung2248@gmail.com', 'Release new product, update more');

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

DROP TABLE IF EXISTS `food`;
CREATE TABLE IF NOT EXISTS `food` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(80) NOT NULL,
  `Amount` int NOT NULL,
  `Price` int NOT NULL,
  `Image` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`ID`, `Name`, `Amount`, `Price`, `Image`) VALUES
(1, 'Lemon Burger', 1, 400, 'lemon burger.jpg'),
(3, 'Green Chili Burger', 1, 500, 'green chilli.jpg'),
(4, 'Taiyaki', 1, 200, 'taiyaki.jpg'),
(5, 'Ramen (Best Seller)', 1, 800, 'ramen.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `jersey_khunai`
--

DROP TABLE IF EXISTS `jersey_khunai`;
CREATE TABLE IF NOT EXISTS `jersey_khunai` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(80) NOT NULL,
  `Amount` int NOT NULL,
  `Price` int NOT NULL,
  `Image` varchar(100) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `jersey_khunai`
--

INSERT INTO `jersey_khunai` (`ID`, `Name`, `Amount`, `Price`, `Image`) VALUES
(3, 'Boruto Cosplay ', 1, 8000, 'boruto cosplay.jpg'),
(4, 'Naruto Headbands', 1, 4000, 'naruto headbands.jpg'),
(5, 'Uchiha Sasuke Sword', 1, 6000, 'Sasuke-Uchiha Sword.jpg'),
(8, 'Akatsuki ', 1, 15000, 'akatsuki.jpg'),
(9, 'New Weapon', 1, 5000, 'new weapon.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `manga`
--

DROP TABLE IF EXISTS `manga`;
CREATE TABLE IF NOT EXISTS `manga` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(80) NOT NULL,
  `Title` varchar(80) NOT NULL,
  `Price` int NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `manga`
--

INSERT INTO `manga` (`ID`, `Name`, `Title`, `Price`) VALUES
(3, 'Boruto Chapter 2', 'The Training Begins!', 2),
(2, 'Boruto Chapter 1', 'Uzumaki Boruto!', 2),
(4, 'Boruto Chapter 3', 'The Chunin Exam Begins!', 2),
(5, 'Boruto Chapter 4', 'Stupid Old Man!', 2),
(10, 'Boruto Chapter 9', 'You Remind Me Of', 2),
(11, 'Boruto Chapter 10', 'My Story!', 2),
(13, 'Boruto Two Blue Vortex', 'Chapter 1', 2),
(14, 'Boruto Two Blue Vortex', 'Chapter 2', 2),
(15, 'Boruto Two Blue Vortex', 'Chapter 3', 2),
(16, 'Boruto Two Blue Vortex', 'Chapter 4', 2),
(17, 'Boruto Two Blue Vortex', 'Chapter 5', 2),
(18, 'Boruto Two Blue Vortex', 'Chapter 6 - 3 Years', 2),
(19, 'Boruto Two Blue Vortex', 'Chapter 7 - The whereabout of sun', 2),
(20, 'Boruto Two Blue Vortex', 'Chapter 8 - Pointless Matter', 2),
(21, 'Boruto Two Blue Vortex', 'Chapter 9 - Nine Tails', 2),
(22, 'Boruto Two Blue Vortex', 'Chapter 10 - Factor', 2),
(23, 'Boruto Two Blue Vortex', 'Chapter 11 - True Power', 2),
(24, 'Boruto Two Blue Vortex', 'Chapter 12 - Coming Soon', 2);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
