<body style="background-color:#FFFBFB;">
<div>
    <br>
      <center>
      <img src="image/logo.png" width="400"/><br>
      <img src="image/naruto.gif" width="600"/><br>
     <a href="index.html"> <img src="image/symbol.jpg" width="300"/></a>
      <br>
      </center>
       </div>
</body>
      
