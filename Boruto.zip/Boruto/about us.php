<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />

  <title>Uzumaki Boruto</title>
  <!-- slider stylesheet -->
  <link rel="stylesheet" type="text/css"
    href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />

  <!-- fonts style -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700|Poppins:400,700|Raleway:400,700&display=swap"
    rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="css/style.css" rel="stylesheet" />
  <!-- responsive style -->
  <link href="css/responsive.css" rel="stylesheet" />
  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }

    body {
      background-color: #fcf8f6e8;
    }
  </style>

  
  <!-- Custom styles for this template -->
  <link href="product.css" rel="stylesheet">

</head>

<body>
    
    <header class="site-header sticky-top py-1">
      <nav class="container d-flex flex-column flex-md-row justify-content-between">
        <a class="py-2" href="#" aria-label="Product">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" class="d-block mx-auto" role="img" viewBox="0 0 24 24"><title>Product</title><circle cx="12" cy="12" r="10"/><path d="M14.31 8l5.74 9.94M9.69 8h11.48M7.38 12l5.74-9.94M9.69 16L3.95 6.06M14.31 16H2.83m13.79-4l-5.74 9.94"/></svg>
        </a>
        <a class="py-2 d-none d-md-inline-block" href="index.html">Home</a>
        <a class="py-2 d-none d-md-inline-block" href="manga.php">Manga</a>
        <a class="py-2 d-none d-md-inline-block" href="jersey & khunai.php">Jersey & Khunai</a>
        <a class="py-2 d-none d-md-inline-block" href="food.php">Food</a>
        <a class="py-2 d-none d-md-inline-block" href="about us.php">About us</a>
      </nav>
    </header>

    <main>
      <img src="image/final chapter.jpg" class="d-block w-100" alt="Cinque Terre">

  <div class="container col-xxl-8 px-4 py-5">
    <div class="row flex-lg-row-reverse align-items-center g-5 py-5">
      <div class="col-10 col-sm-8 col-lg-6">
        <img src="image/final fight.jpg" class="d-block mx-lg-auto img-fluid" alt="Bootstrap Themes" width="700" height="500" loading="lazy">
      </div>
      <div class="col-lg-6">
        <h1 class="display-5 fw-bold lh-1 mb-3">Boruto & Kawaki final fight</h1>
        <p class="lead">Kawaki Fights Boruto Because He Wants to Kill all Ōtsutsuki. But just like their future fight, everything was kept ambiguous as to who did what. There was no definitive answer as to who the perpetrator actually was. It's also possible that Boruto could actually be the villain, not Kawaki.</p>
      </div>
    </div>
  </div>

  <center>
    <div class="contact-from">
        <div class="form-area">
            <div class="animated fadeInDown">
                <h2>About</h2>
                <p>If you want something, pls give me advice or suggestion. I will be more update manga and new product.</p>
                <br>
            </div>

            <?php
    error_reporting(1);
    include('connection.php');
    if(isset($_POST['sub'])) {  
        $name = $_POST['name'];
        $email = $_POST['email'];
        $suggestion = $_POST['suggestion'];

        // Enclose `order` table name in backticks
        $query = "INSERT INTO `feedback` VALUES ('', '$name', '$email', '$suggestion')";
        $con->query($query); 
        
        echo "<p style='color:green'>Message Sent Successfully!</p>";
    }
?>

            
            <div class="contact">
                <div class="map animated fadeInLeft">
                <img src="image/last photo.jpg" class="d-block w-100" alt="Cinque Terre">             
                </div>

                <form method="post" class="form animated fadeInUp">
                   

                    <label>
                        <input type="text" class="subject" id="subject" name="name" required>
                        <div class="label subject-text">Name</div>
                    </label>

                    <label>
                        <input type="email" class="email" id="email" name="email" required>
                        <div class="label email-text">E-mail</div>
                    </label>

                    <label>
                        <textarea class="help-box" id="helpBox" cols="30" rows="10" required name="suggestion"></textarea>
                        <div class="label help-text">Suggestion</div>
                    </label>

                   <div class="row">
                        <div class="col-4"></div>
                        <div class="col-4">
                        <input type="submit" value="Submit" name="sub" class="btn btn-outline-success" >
                        </div>
                        <div class="col-4"></div>
                   </div>   
                </form>
            </div>
        </div>
    </div>
<br>

    </center>

    </main>

    <section class="container-fluid footer_section">
      <p>
        &copy; 2024 All Rights Reserved. Design by
        <a href="https://www.facebook.com/profile.php?id=100008265902254&mibextid=LQQJ4d">Hein Thant</a>
      </p>
    </section>

    <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.js"></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>

  <script>
    function openNav() {
      document.getElementById("myNav").classList.toggle("menu_width");
      document
        .querySelector(".custom_menu-btn")
        .classList.toggle("menu_btn-style");
    }
  </script>

  <!-- end owl carousel script -->
<style>

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');

.contact-from {
    width: 1150px;
    height: 560px;
    padding: 50px 80px;
    background: url(../images/images.png);
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
    display: flex;
    justify-content: center;    
    transition: .5s all ease;

    .form-area {      

        h2 {
            font-weight: 500;
            font-size: 28px;
            color: #4F4F4F;
            text-align: center;
            transition: .5s all ease;
        }

        p {
            max-width: 340px;
            font-weight: 300;
            color: #464646;
            margin: auto;
            text-align: center;
        }
    }

    .contact {
        margin-top: 25px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        transition: .5s all ease;

        .map {
            width: 400px;
            margin-right: 35px;
            animation-duration: 1.5s;

            iframe {
                width: 100%;
                height: 300px;
                box-shadow: 0 0 8px rgba(0,0,0, .3);
                
            }
        }

        .form {
            width: 525px;
            transition: .5s all ease;
            animation-duration: 1.5s;

            .label {
                background-color: white;
                color: #6b6b6b;
                font-size: 17px;
                font-weight: 300;
                margin: 0 8px;
                padding: 0 5px;
                position: absolute;
                transition: 0.5s all cubic-bezier(0.5, 1.35, 0.5, 1.35);
            }
            
            .email-text {
                transform: translateY(-51px);
            }

            .subject-text {
                transform: translateY(-52px);
            }

            .help-text {
                transform: translateY(-112px);
            }
           
            input, textarea {
                width: 100%;
                padding: 10px;
                border: 1px solid #DADCE0;
                border-radius: 5px;
                outline: none;
                margin-bottom: 20px;
                transition: .3s;

                &:focus {
                    border: 1px solid #4285F4;
                    box-shadow: inset 1px 1px 0 #4285F4, inset -1px -1px 0 #4285F4;
                }    
                
                &:focus + .label, &:valid + .label {
                    font-size: 13px;
                    font-weight: 600;
                    color: #4285F4;                  
                }
                
                &:focus + .email-text, &:valid + .email-text  {
                    transform: translateY(-67px);               
                }

                &:focus + .subject-text, &:valid + .subject-text {
                    transform: translateY(-67px);                
                }
                
                &:focus + .help-text, &:valid + .help-text {
                    transform: translateY(-127px);                
                }
            }

            textarea {
                max-height: 90px;   
                max-width: 100%;            
            }

            .submit-area {
                position: relative;

                #submit {
                    position: relative;
                    display: inline-block;
                    width: 105px;
                    text-align: left;
                    padding: 10px 20px;
                    border: none;
                    border-radius: 1px;
                    cursor: pointer;
                    background-color: #33B5E5;
                    color: #fff;
                    text-transform: uppercase;
                    font-size: 11px;
                    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
                    transition: .1s all ease;
    
                    &:hover {
                        box-shadow: 0 7px 15px transparentize(#000, .75);
                    }                    
                }
                i.fa-paper-plane {
                    position: absolute;
                    left: 70px;
                    top: 9px;
                    color: #fff;
                    font-size: 13px;
                }                
            }           
        }
    }
}



@media screen and (max-width: 1200px){
    .contact-from {
        width: 960px;
        padding: 50px 60px;

        .contact {
            .map {
                width: 320px;
            }

            .form {
                width: 485px;
            }
        }
    }
}
@media screen and (max-width: 992px){
    .contact-from {
        width: 710px;
        height: auto;
       
      .form-area{
            margin-top: 200px;
        }

        .contact {
            flex-direction: column;

            .map {
                width: 100%;
                margin-right: 0;
                margin-bottom: 30px;
            }

            .form {
                width: 100%;
            }
        }
    }
}
@media screen and (max-width: 768px){
    .contact-from {
        width: 100%;
    }
}
</style>

  </body>
  </html>