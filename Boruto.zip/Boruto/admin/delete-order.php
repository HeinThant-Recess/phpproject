<?php
include("connection.php"); 
$q = "delete from `boruto_order` where id='{$_GET['id']}'";
$con->query($q);
header('location:order.php');
?>