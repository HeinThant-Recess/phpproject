<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="boruto.css" />
    <title>Boruto Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>

        <?php
        error_reporting(1);
        if (isset($_GET['sub'])) {
            $eid = $_GET['n'];
            $pass = $_GET['p'];

            if ($eid == '' || $pass == '') {
                echo "<p style=\"color: red; text-align: center; margin-left:-15px\"
         >Please fill username or password</p>";
            } else {
                if ($eid == "Recess" && $pass == "borutoproject") {
                    header('location:boruto.html');
                } else {
                    echo "<p style=\"color: red; text-align: center;margin-left:-15px\"
        >username or password Wrong!</p>";
                }
            }
        }
        ?>
<form class="login-form">
  <p class="login-text">
    <span class="fa-stack fa-lg">
      <i class="fa fa-circle fa-stack-2x"></i>
      <i class="fa fa-lock fa-stack-1x"></i>
    </span>
  </p>
  <input type="text" class="login-username" autofocus="true" required="true" placeholder="Username" name="n"/>
  <input type="password" class="login-password" required="true" placeholder="Password" name="p"/>
  <input type="submit" name="sub" value="Login" class="login-submit" />
</form>
<a href="#" class="login-forgot-pass">forgot password?</a>
<div class="underlay-photo"></div>
<div class="underlay-black"></div> 
</body>
