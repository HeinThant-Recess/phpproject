<?php
include("connection.php"); 
$q = "delete from manga where id='{$_GET['id']}'";
$con->query($q);
unlink("img/".$_GET['img']);
header('location:manga.php');
?>